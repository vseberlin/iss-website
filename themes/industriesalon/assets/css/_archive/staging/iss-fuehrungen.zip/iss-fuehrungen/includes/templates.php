<?php

if (!defined('ABSPATH')) {
    exit;
}

add_filter('template_include', function ($template) {
    if (is_singular(ISS_FUEHRUNGEN_POST_TYPE)) {
        return ISS_FUEHRUNGEN_PATH . 'templates/single-fuehrung.php';
    }

    if (is_post_type_archive(ISS_FUEHRUNGEN_POST_TYPE) || is_tax('fuehrung_typ')) {
        return ISS_FUEHRUNGEN_PATH . 'templates/archive-fuehrung.php';
    }

    return $template;
}, 99);
