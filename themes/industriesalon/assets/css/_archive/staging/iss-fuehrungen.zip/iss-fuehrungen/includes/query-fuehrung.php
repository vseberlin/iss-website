<?php

if (!defined('ABSPATH')) {
    exit;
}

function iss_fuehrung_get_upcoming_events($post_id, $limit = 12) {
    if (!defined('ISS_CALENDAR_ITEM_POST_TYPE')) {
        return [];
    }

    $post_id = (int) $post_id;
    if ($post_id <= 0) {
        return [];
    }

    $query = new WP_Query([
        'post_type'      => ISS_CALENDAR_ITEM_POST_TYPE,
        'post_status'    => 'publish',
        'posts_per_page' => max(1, (int) $limit),
        'meta_key'       => 'event_start',
        'orderby'        => 'meta_value',
        'order'          => 'ASC',
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'     => 'source_post_id',
                'value'   => $post_id,
                'compare' => '=',
                'type'    => 'NUMERIC',
            ],
            [
                'key'     => 'event_start',
                'value'   => current_time('mysql'),
                'compare' => '>=',
                'type'    => 'DATETIME',
            ],
        ],
    ]);

    return $query->posts;
}

function iss_fuehrung_get_next_event($post_id) {
    $events = iss_fuehrung_get_upcoming_events($post_id, 1);
    return $events ? $events[0] : null;
}

function iss_fuehrung_get_event_start_label($event_id) {
    $start = get_post_meta($event_id, 'event_start', true);
    if (!$start) {
        return '';
    }

    $timestamp = strtotime((string) $start);
    if (!$timestamp) {
        return (string) $start;
    }

    return wp_date('j. F Y, H:i', $timestamp);
}

function iss_fuehrung_get_event_booking_url($event_id, $post_id = 0) {
    $url = (string) get_post_meta($event_id, 'booking_url', true);
    if ($url !== '') {
        return $url;
    }

    if ($post_id > 0) {
        $url = (string) get_post_meta($post_id, 'fallback_url', true);
        if ($url !== '') {
            return $url;
        }
    }

    return '';
}

function iss_fuehrung_get_card_meta($post_id) {
    $parts = [];

    foreach (['duration', 'meeting_point', 'target_group'] as $key) {
        $value = trim((string) get_post_meta($post_id, $key, true));
        if ($value !== '') {
            $parts[] = $value;
        }
    }

    return $parts;
}

function iss_fuehrung_get_related($post_id, $limit = 3) {
    $terms = wp_get_post_terms($post_id, 'fuehrung_typ', ['fields' => 'ids']);

    $tax_query = [];
    if (!is_wp_error($terms) && !empty($terms)) {
        $tax_query[] = [
            'taxonomy' => 'fuehrung_typ',
            'field'    => 'term_id',
            'terms'    => $terms,
        ];
    }

    return get_posts([
        'post_type'      => ISS_FUEHRUNGEN_POST_TYPE,
        'posts_per_page' => max(1, (int) $limit),
        'post__not_in'   => [$post_id],
        'orderby'        => ['menu_order' => 'ASC', 'date' => 'DESC'],
        'tax_query'      => $tax_query,
    ]);
}
