<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('add_meta_boxes', function () {
    add_meta_box(
        'iss-fuehrung-data',
        __('Führungsdaten', 'iss-fuehrungen'),
        'iss_fuehrungen_render_meta_box',
        ISS_FUEHRUNGEN_POST_TYPE,
        'side',
        'high'
    );
});

function iss_fuehrungen_render_meta_box($post) {
    wp_nonce_field('iss_fuehrung_save_meta', 'iss_fuehrung_meta_nonce');

    $fields = [
        'duration'      => __('Dauer', 'iss-fuehrungen'),
        'meeting_point' => __('Treffpunkt', 'iss-fuehrungen'),
        'target_group'  => __('Zielgruppe', 'iss-fuehrungen'),
        'price_note'    => __('Preishinweis', 'iss-fuehrungen'),
        'booking_note'  => __('Buchungshinweis', 'iss-fuehrungen'),
        'tour_badge'    => __('Badge', 'iss-fuehrungen'),
        'tour_icon'     => __('Icon', 'iss-fuehrungen'),
        'sort_weight'   => __('Sortierung', 'iss-fuehrungen'),
    ];

    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, $key, true);
        echo '<p>';
        echo '<label for="iss_' . esc_attr($key) . '"><strong>' . esc_html($label) . '</strong></label>';

        if ($key === 'booking_note') {
            echo '<textarea class="widefat" rows="3" id="iss_' . esc_attr($key) . '" name="iss_fuehrung[' . esc_attr($key) . ']">' . esc_textarea((string) $value) . '</textarea>';
        } elseif ($key === 'sort_weight') {
            echo '<input class="widefat" type="number" step="1" min="0" id="iss_' . esc_attr($key) . '" name="iss_fuehrung[' . esc_attr($key) . ']" value="' . esc_attr((string) $value) . '">';
        } else {
            echo '<input class="widefat" type="text" id="iss_' . esc_attr($key) . '" name="iss_fuehrung[' . esc_attr($key) . ']" value="' . esc_attr((string) $value) . '">';
        }
        echo '</p>';
    }

    $tour_color = get_post_meta($post->ID, 'tour_color', true);
    $tour_color = $tour_color ?: 'red';
    $is_featured = (bool) get_post_meta($post->ID, 'is_featured', true);

    echo '<p><label for="iss_tour_color"><strong>' . esc_html__('Farbakzent', 'iss-fuehrungen') . '</strong></label>';
    echo '<select class="widefat" id="iss_tour_color" name="iss_fuehrung[tour_color]">';
    foreach (['red' => 'Rot', 'blue' => 'Blau', 'green' => 'Grün', 'yellow' => 'Gelb', 'brown' => 'Braun'] as $value => $label) {
        printf('<option value="%s" %s>%s</option>', esc_attr($value), selected($tour_color, $value, false), esc_html($label));
    }
    echo '</select></p>';

    echo '<p><label><input type="checkbox" name="iss_fuehrung[is_featured]" value="1" ' . checked($is_featured, true, false) . '> ' . esc_html__('Auf Landingpages hervorheben', 'iss-fuehrungen') . '</label></p>';

    echo '<p style="margin-top:1rem;color:#666;font-size:12px;line-height:1.5;">';
    echo esc_html__('Lange Beschreibung, Absätze und Medien bitte im normalen Editor pflegen. Hier nur strukturierte Fakten eintragen.', 'iss-fuehrungen');
    echo '</p>';
}

add_action('save_post_' . ISS_FUEHRUNGEN_POST_TYPE, function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!isset($_POST['iss_fuehrung_meta_nonce']) || !wp_verify_nonce((string) $_POST['iss_fuehrung_meta_nonce'], 'iss_fuehrung_save_meta')) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $raw = isset($_POST['iss_fuehrung']) && is_array($_POST['iss_fuehrung']) ? wp_unslash($_POST['iss_fuehrung']) : [];
    $fields = iss_fuehrungen_meta_fields();

    foreach ($fields as $key => $config) {
        $value = $raw[$key] ?? ($config['type'] === 'boolean' ? '' : $config['default']);
        $sanitizer = $config['sanitize'];
        $value = is_callable($sanitizer) ? $sanitizer($value) : call_user_func($sanitizer, $value);

        if ($config['type'] === 'boolean') {
            $value = $value ? '1' : '';
        }

        if ($value === '' || $value === false || $value === null) {
            delete_post_meta($post_id, $key);
        } else {
            update_post_meta($post_id, $key, $value);
        }
    }
}, 10, 1);
