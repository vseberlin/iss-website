<?php

if (!defined('ABSPATH')) {
    exit;
}

function iss_fuehrung_get_color_class($post_id) {
    $color = get_post_meta($post_id, 'tour_color', true);
    $color = $color ?: 'red';
    return 'iss-fuehrung--' . sanitize_html_class($color);
}

function iss_fuehrung_render_facts($post_id) {
    $items = [
        'Dauer'      => get_post_meta($post_id, 'duration', true),
        'Treffpunkt' => get_post_meta($post_id, 'meeting_point', true),
        'Zielgruppe' => get_post_meta($post_id, 'target_group', true),
        'Preis'      => get_post_meta($post_id, 'price_note', true),
    ];

    $items = array_filter($items, static function ($value) {
        return trim((string) $value) !== '';
    });

    if (!$items) {
        return '';
    }

    ob_start();
    echo '<div class="iss-fuehrung-facts">';
    foreach ($items as $label => $value) {
        echo '<div class="iss-fuehrung-fact">';
        echo '<div class="iss-fuehrung-fact__label">' . esc_html($label) . '</div>';
        echo '<div class="iss-fuehrung-fact__value">' . esc_html((string) $value) . '</div>';
        echo '</div>';
    }
    echo '</div>';
    return (string) ob_get_clean();
}

function iss_fuehrung_render_booking_box($post_id) {
    $next_event = iss_fuehrung_get_next_event($post_id);
    $booking_note = trim((string) get_post_meta($post_id, 'booking_note', true));
    $archive_link = get_post_type_archive_link(ISS_FUEHRUNGEN_POST_TYPE);

    ob_start();
    echo '<aside class="iss-fuehrung-booking">';
    echo '<div class="iss-fuehrung-booking__inner">';
    echo '<p class="iss-kicker iss-kicker--compact">Buchung</p>';

    if ($next_event instanceof WP_Post) {
        $date_label = iss_fuehrung_get_event_start_label($next_event->ID);
        $availability = trim((string) get_post_meta($next_event->ID, 'availability_state', true));
        $booking_url = iss_fuehrung_get_event_booking_url($next_event->ID, $post_id);

        echo '<h2 class="iss-fuehrung-booking__title">Nächster Termin</h2>';
        echo '<p class="iss-fuehrung-next-date">' . esc_html($date_label) . '</p>';

        if ($availability !== '') {
            echo '<p class="iss-fuehrung-booking__status">' . esc_html($availability) . '</p>';
        }

        if ($booking_note !== '') {
            echo '<p class="iss-fuehrung-booking__note">' . esc_html($booking_note) . '</p>';
        }

        echo '<div class="iss-fuehrung-booking__actions">';
        if ($booking_url !== '') {
            echo '<a class="wp-element-button" href="' . esc_url($booking_url) . '">Buchen</a>';
        }
        echo '<a class="iss-fuehrung-booking__secondary" href="#termine">Alle Termine</a>';
        echo '</div>';
    } else {
        echo '<h2 class="iss-fuehrung-booking__title">Aktuell keine Termine online</h2>';
        if ($booking_note !== '') {
            echo '<p class="iss-fuehrung-booking__note">' . esc_html($booking_note) . '</p>';
        } else {
            echo '<p class="iss-fuehrung-booking__note">Für Gruppen, Sonderformate oder Rückfragen nehmen Sie bitte Kontakt mit dem Industriesalon auf.</p>';
        }
        echo '<div class="iss-fuehrung-booking__actions">';
        if ($archive_link) {
            echo '<a class="iss-fuehrung-booking__secondary" href="' . esc_url($archive_link) . '">Alle Führungen</a>';
        }
        echo '</div>';
    }

    echo '</div>';
    echo '</aside>';
    return (string) ob_get_clean();
}

function iss_fuehrung_render_archive_card($post_id) {
    $permalink = get_permalink($post_id);
    $badge = trim((string) get_post_meta($post_id, 'tour_badge', true));
    $meta = iss_fuehrung_get_card_meta($post_id);
    $next_event = iss_fuehrung_get_next_event($post_id);
    $color_class = iss_fuehrung_get_color_class($post_id);

    ob_start();
    echo '<article class="iss-card iss-fuehrung-card ' . esc_attr($color_class) . '">';

    if (has_post_thumbnail($post_id)) {
        echo '<a class="iss-card__media" href="' . esc_url($permalink) . '">';
        echo get_the_post_thumbnail($post_id, 'large');
        echo '</a>';
    }

    echo '<div class="iss-card__body">';
    if ($badge !== '') {
        echo '<p class="iss-kicker iss-kicker--compact">' . esc_html($badge) . '</p>';
    }

    echo '<h2 class="iss-card__title"><a href="' . esc_url($permalink) . '">' . esc_html(get_the_title($post_id)) . '</a></h2>';

    $excerpt = get_the_excerpt($post_id);
    if ($excerpt !== '') {
        echo '<p class="iss-card__text">' . esc_html($excerpt) . '</p>';
    }

    if ($meta) {
        echo '<p class="iss-fuehrung-card__meta">' . esc_html(implode(' · ', $meta)) . '</p>';
    }

    if ($next_event instanceof WP_Post) {
        echo '<p class="iss-fuehrung-card__date"><strong>Nächster Termin:</strong> ' . esc_html(iss_fuehrung_get_event_start_label($next_event->ID)) . '</p>';
    } else {
        echo '<p class="iss-fuehrung-card__date"><strong>Status:</strong> Aktuell keine Termine online</p>';
    }

    echo '<div class="iss-card__footer">';
    echo '<a class="iss-card__link" href="' . esc_url($permalink) . '">Mehr erfahren</a>';
    echo '</div>';
    echo '</div>';
    echo '</article>';

    return (string) ob_get_clean();
}
