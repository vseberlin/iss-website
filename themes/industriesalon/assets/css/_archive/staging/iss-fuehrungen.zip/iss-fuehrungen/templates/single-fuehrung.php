<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();

the_post();
$post_id = get_the_ID();
$badge = trim((string) get_post_meta($post_id, 'tour_badge', true));
$color_class = iss_fuehrung_get_color_class($post_id);
?>
<main class="wp-site-blocks">
    <?php echo do_blocks('<!-- wp:template-part {"slug":"header","tagName":"header"} /-->'); ?>

    <article <?php post_class('iss-fuehrung-single section ' . $color_class); ?>>
        <?php if (has_post_thumbnail()) : ?>
            <section class="iss-fuehrung-hero">
                <?php the_post_thumbnail('full'); ?>
            </section>
        <?php endif; ?>

        <section class="iss-container iss-fuehrung-intro-wrap">
            <div class="iss-fuehrung-intro">
                <div class="iss-fuehrung-intro__main">
                    <div class="iss-heading">
                        <?php if ($badge !== '') : ?>
                            <p class="iss-kicker iss-kicker--lg"><?php echo esc_html($badge); ?></p>
                        <?php endif; ?>
                        <h1 class="iss-heading__title"><?php the_title(); ?></h1>
                        <?php if (has_excerpt()) : ?>
                            <p class="iss-heading__text"><?php echo esc_html(get_the_excerpt()); ?></p>
                        <?php endif; ?>
                    </div>

                    <?php echo iss_fuehrung_render_facts($post_id); ?>
                </div>

                <div class="iss-fuehrung-intro__aside">
                    <?php echo iss_fuehrung_render_booking_box($post_id); ?>
                </div>
            </div>
        </section>

        <section id="termine" class="iss-container iss-fuehrung-dates-wrap section--with-rail">
            <div class="iss-heading">
                <p class="iss-kicker iss-kicker--compact">Termine</p>
                <h2 class="iss-heading__title">Verfügbare Termine</h2>
                <p class="iss-heading__text">Der Kalender wird aus SuperSaaS synchronisiert. Die Liste darunter bleibt zusätzlich als ruhige, SEO-freundliche Darstellung sichtbar.</p>
            </div>

            <div class="iss-fuehrung-dates-grid">
                <div class="iss-fuehrung-dates-grid__calendar">
                    <?php
                    echo do_blocks('<!-- wp:iss/tour-calendar {"title":"Termin wählen"} /-->');
                    ?>
                </div>
                <div class="iss-fuehrung-dates-grid__list">
                    <?php
                    echo do_blocks('<!-- wp:iss/tour-dates {"title":"Nächste Termine","limit":12} /-->');
                    ?>
                </div>
            </div>
        </section>

        <section class="iss-container iss-fuehrung-content-wrap">
            <div class="iss-fuehrung-content">
                <?php the_content(); ?>
            </div>
        </section>

        <?php $related = iss_fuehrung_get_related($post_id, 3); ?>
        <?php if ($related) : ?>
            <section class="iss-container iss-fuehrung-related-wrap">
                <div class="iss-heading">
                    <p class="iss-kicker iss-kicker--compact">Weitersehen</p>
                    <h2 class="iss-heading__title">Weitere Führungen</h2>
                </div>
                <div class="iss-card-grid iss-fuehrung-related-grid">
                    <?php foreach ($related as $related_post) : ?>
                        <?php echo iss_fuehrung_render_archive_card($related_post->ID); ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    </article>

    <?php echo do_blocks('<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->'); ?>
</main>
<?php
get_footer();
