(function () {
    if (window.__issNavInit) {
        return;
    }
    window.__issNavInit = true;

    function init() {
        var header = document.querySelector('.iss-site-header');
        var toggle = document.querySelector('.iss-nav-toggle');
        var panel = document.querySelector('.iss-menu-shell');
        var overlay = document.querySelector('.iss-nav-overlay');
        var close = document.querySelector('.iss-menu-shell__close');

        if (!header || !toggle || !panel || !overlay || !close) {
            return;
        }

        var focusableSelector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';
        var lastFocusedElement = null;

        function getFocusable() {
            return Array.prototype.slice.call(panel.querySelectorAll(focusableSelector)).filter(function (el) {
                return el.offsetParent !== null;
            });
        }

        function openNav() {
            lastFocusedElement = document.activeElement;
            document.documentElement.classList.add('iss-nav-open');
            document.body.classList.add('iss-nav-open');
            panel.classList.add('is-open');
            overlay.classList.add('is-open');
            toggle.setAttribute('aria-expanded', 'true');

            var items = getFocusable();
            if (items.length) {
                window.setTimeout(function () {
                    items[0].focus();
                }, 20);
            }
        }

        function closeNav() {
            document.documentElement.classList.remove('iss-nav-open');
            document.body.classList.remove('iss-nav-open');
            panel.classList.remove('is-open');
            overlay.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');

            if (lastFocusedElement && typeof lastFocusedElement.focus === 'function') {
                lastFocusedElement.focus();
            } else {
                toggle.focus();
            }
        }

        function onKeydown(event) {
            if (!panel.classList.contains('is-open')) {
                return;
            }

            if (event.key === 'Escape') {
                event.preventDefault();
                closeNav();
                return;
            }

            if (event.key !== 'Tab') {
                return;
            }

            var items = getFocusable();
            if (!items.length) {
                return;
            }

            var first = items[0];
            var last = items[items.length - 1];

            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        }

        toggle.addEventListener('click', function () {
            if (panel.classList.contains('is-open')) {
                closeNav();
            } else {
                openNav();
            }
        });

        close.addEventListener('click', closeNav);
        overlay.addEventListener('click', closeNav);
        document.addEventListener('keydown', onKeydown);

        panel.addEventListener('click', function (event) {
            var link = event.target.closest('a');
            if (link) {
                closeNav();
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
