<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
});

add_action('wp_enqueue_scripts', function () {
    $theme = wp_get_theme();

    wp_enqueue_script(
        'industriesalon-header',
        get_stylesheet_directory_uri() . '/assets/js/header.js',
        array(),
        $theme->get('Version'),
        true
    );
}, 20);
