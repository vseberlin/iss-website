<?php

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/includes/calendar-cpt.php';
require_once __DIR__ . '/includes/calendar-sync.php';
require_once __DIR__ . '/includes/calendar-query.php';
require_once __DIR__ . '/includes/calendar-render.php';

require_once __DIR__ . '/includes/blocks.php';
require_once __DIR__ . '/includes/calendar-editor.php';
require_once __DIR__ . '/includes/calendar-linking.php';
