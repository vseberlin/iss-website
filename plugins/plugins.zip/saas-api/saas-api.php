<?php
/**
 * Plugin Name: SuperSaaS API
 * Description: SuperSaaS data adapter: settings, sync, local slot storage, mapping, and booking REST endpoints.
 * Version: 1.2.0
 */

if (!defined('ABSPATH')) exit;

define('IS_SAAS_OPTION_GROUP', 'is_saas_options');
define('IS_SAAS_OPTION_NAME', 'is_saas_settings');

require_once __DIR__ . '/iss-calendar/iss-calendar.php';

register_activation_hook(__FILE__, 'iss_calendar_activate_sync');
register_deactivation_hook(__FILE__, 'iss_calendar_deactivate_sync');

function is_saas_get_settings() {
    $defaults = [
        'schedule_id'   => '',
        'api_key'       => '',
        'base_url'      => 'https://www.supersaas.de',
        'account_name'  => '',
        'schedule_path' => '',
    ];

    $settings = get_option(IS_SAAS_OPTION_NAME, []);
    if (!is_array($settings)) {
        $settings = [];
    }

    return array_merge($defaults, $settings);
}

function is_saas_get_schedule_path($settings = null) {
    if ($settings === null) {
        $settings = is_saas_get_settings();
    }

    if (!empty($settings['schedule_path'])) {
        return $settings['schedule_path'];
    }

    return '';
}

function is_saas_normalize_schedule_path($schedule_path) {
    $schedule_path = trim((string) $schedule_path);
    if ($schedule_path === '') {
        return '';
    }

    return str_replace('%2F', '/', rawurlencode(rawurldecode($schedule_path)));
}

function is_saas_register_settings() {
    register_setting(
        IS_SAAS_OPTION_GROUP,
        IS_SAAS_OPTION_NAME,
        [
            'sanitize_callback' => 'is_saas_sanitize_settings',
            'default' => [],
        ]
    );

    add_settings_section(
        'is_saas_main',
        'SuperSaaS Configuration',
        '__return_false',
        IS_SAAS_OPTION_GROUP
    );

    add_settings_field('schedule_id', 'Schedule ID', 'is_saas_field_schedule_id', IS_SAAS_OPTION_GROUP, 'is_saas_main');
    add_settings_field('api_key', 'API Key', 'is_saas_field_api_key', IS_SAAS_OPTION_GROUP, 'is_saas_main');
    add_settings_field('base_url', 'API Base URL', 'is_saas_field_base_url', IS_SAAS_OPTION_GROUP, 'is_saas_main');
    add_settings_field('account_name', 'Account Name', 'is_saas_field_account_name', IS_SAAS_OPTION_GROUP, 'is_saas_main');
    add_settings_field('schedule_path', 'Schedule Path', 'is_saas_field_schedule_path', IS_SAAS_OPTION_GROUP, 'is_saas_main');
}
add_action('admin_init', 'is_saas_register_settings');

function is_saas_sanitize_settings($input) {
    $out = [];
    $out['schedule_id']   = isset($input['schedule_id']) ? preg_replace('/[^0-9]/', '', $input['schedule_id']) : '';
    $out['api_key']       = isset($input['api_key']) ? sanitize_text_field($input['api_key']) : '';
    $out['base_url']      = isset($input['base_url']) ? esc_url_raw(trim($input['base_url'])) : '';
    $out['account_name']  = isset($input['account_name']) ? sanitize_text_field($input['account_name']) : '';
    $out['schedule_path'] = isset($input['schedule_path']) ? trim((string) $input['schedule_path']) : '';
    return $out;
}

function is_saas_add_admin_menu() {
    add_options_page(
        'SuperSaaS API',
        'SuperSaaS API',
        'manage_options',
        'is-saas-api',
        'is_saas_render_settings_page'
    );
}
add_action('admin_menu', 'is_saas_add_admin_menu');

function is_saas_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>SuperSaaS API</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields(IS_SAAS_OPTION_GROUP);
            do_settings_sections(IS_SAAS_OPTION_GROUP);
            submit_button();
            ?>
        </form>
        <p><strong>Shortcode:</strong> <code>[is_tour_calendar tag="ELEKTRO" title="Termine wählen" fallback_url="https://example.com"]</code></p>
    </div>
    <?php
}

function is_saas_build_slot_response($slot, $title, $start) {
    $available = null;
    if (isset($slot['available'])) {
        $available = (int) $slot['available'];
    } elseif (isset($slot['remaining'])) {
        $available = (int) $slot['remaining'];
    } elseif (isset($slot['count'])) {
        $available = (int) $slot['count'];
    }

    return [
        'id'        => isset($slot['id']) ? (string) $slot['id'] : '',
        'title'     => $title,
        'start'     => $start,
        'end'       => $slot['end'] ?? ($slot['finish'] ?? null),
        'capacity'  => isset($slot['capacity']) ? (int) $slot['capacity'] : null,
        'available' => $available,
        'booking_url' => null,
    ];
}

function is_saas_resolve_calendar_item_title($item_id) {
    $item_id = (int) $item_id;
    if ($item_id <= 0) {
        return '';
    }

    $source_post_id = (int) get_post_meta($item_id, 'source_post_id', true);
    if ($source_post_id > 0) {
        $linked_title = trim((string) get_the_title($source_post_id));
        if ($linked_title !== '') {
            return $linked_title;
        }
    }

    return (string) get_the_title($item_id);
}

function is_saas_resolve_calendar_item_content_url($item_id) {
    $item_id = (int) $item_id;
    if ($item_id <= 0) {
        return null;
    }

    if (function_exists('iss_calendar_get_item_source_permalink')) {
        $source_link = (string) iss_calendar_get_item_source_permalink($item_id);
        if ($source_link !== '') {
            return $source_link;
        }
    }

    $source_post_id = (int) get_post_meta($item_id, 'source_post_id', true);
    if ($source_post_id <= 0) {
        return null;
    }

    $source_link = get_permalink($source_post_id);
    if (!is_string($source_link) || trim($source_link) === '') {
        return null;
    }

    return $source_link;
}

function is_saas_field_schedule_id() {
    $settings = is_saas_get_settings();
    printf(
        '<input type="text" name="%s[schedule_id]" value="%s" class="regular-text" />',
        esc_attr(IS_SAAS_OPTION_NAME),
        esc_attr($settings['schedule_id'])
    );
}

function is_saas_field_api_key() {
    $settings = is_saas_get_settings();
    printf(
        '<input type="password" name="%s[api_key]" value="%s" class="regular-text" autocomplete="new-password" />',
        esc_attr(IS_SAAS_OPTION_NAME),
        esc_attr($settings['api_key'])
    );
}

function is_saas_field_base_url() {
    $settings = is_saas_get_settings();
    printf(
        '<input type="text" name="%s[base_url]" value="%s" class="regular-text" />',
        esc_attr(IS_SAAS_OPTION_NAME),
        esc_attr($settings['base_url'])
    );
    echo '<p class="description">Example: https://www.supersaas.de</p>';
}

function is_saas_field_account_name() {
    $settings = is_saas_get_settings();
    printf(
        '<input type="text" name="%s[account_name]" value="%s" class="regular-text" />',
        esc_attr(IS_SAAS_OPTION_NAME),
        esc_attr($settings['account_name'])
    );
    echo '<p class="description">Used for booking links.</p>';
}

function is_saas_field_schedule_path() {
    $settings = is_saas_get_settings();
    printf(
        '<input type="text" name="%s[schedule_path]" value="%s" class="regular-text" />',
        esc_attr(IS_SAAS_OPTION_NAME),
        esc_attr($settings['schedule_path'])
    );
    echo '<p class="description">Required for booking links. Example: Fuehrungen_%28oeffentlich%29</p>';
}

add_action('rest_api_init', function () {
    register_rest_route('is-tours/v1', '/slots', [
        'methods'  => 'GET',
        'callback' => 'is_tours_get_slots',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('is-tours/v1', '/book', [
        'methods'  => 'POST',
        'callback' => 'is_tours_create_booking',
        'permission_callback' => '__return_true',
    ]);

});


function is_tours_get_slots(WP_REST_Request $request) {
    $tag = strtoupper(sanitize_text_field($request->get_param('tag')));
    $source_post_id = (int) $request->get_param('post_id');

    if (!$tag && $source_post_id > 0) {
        $tag = strtoupper(sanitize_text_field((string) get_post_meta($source_post_id, 'calendar_tag', true)));
        if (!$tag && function_exists('iss_calendar_resolve_tag_for_source_post_id')) {
            $tag = iss_calendar_resolve_tag_for_source_post_id($source_post_id);
        }
    }

    if (!$tag && $source_post_id <= 0) {
        // Return empty array (UI will show fallback link). Also signals the reason via header.
        $res = new WP_REST_Response(['source' => 'nomap', 'slots' => []], 200);
        $res->header('X-IS-Tours-Source', 'nomap');
        $res->header('X-IS-Tours-Error', 'missing-tag');
        $res->header('Cache-Control', 'no-store');
        return $res;
    }

    if ($tag !== '' && $source_post_id <= 0) {
        $cache_key = 'is_tours_slots_' . md5($tag);
        $cached = get_transient($cache_key);
    } else {
        $cached = false;
    }

    if ($cached !== false) {
        $cached_at = is_tours_get_cached_at_by_tag($tag);
        $source = is_tours_get_cached_source_by_tag($tag);
        if ($source === '' || $source === 'cache') {
            $source = 'cpt';
            is_tours_set_cached_source_by_tag($tag, $source, 60 * 10);
        }
        $payload = ['source' => $source, 'slots' => is_array($cached) ? $cached : []];
        $etag = is_tours_build_etag($payload);
        $maybe = is_tours_maybe_304($request, $etag, $cached_at, 60);
        if ($maybe) {
            $maybe->header('X-IS-Tours-Source', 'cache');
            return $maybe;
        }

        $res = new WP_REST_Response($payload, 200);
        $res->header('X-IS-Tours-Source', 'cache');
        if ($etag !== '') $res->header('ETag', $etag);
        $res->header('Cache-Control', 'public, max-age=60');
        if ($cached_at > 0) {
            $res->header('Last-Modified', gmdate('D, d M Y H:i:s', $cached_at) . ' GMT');
        }
        return $res;
	    }

    if (
        !function_exists('iss_calendar_get_slots_fallback_for_tag')
        && !function_exists('iss_calendar_get_items_for_post')
    ) {
        return new WP_REST_Response([
            'error' => 'Calendar module missing',
        ], 500);
    }

    $slots = is_tours_get_cpt_slots($tag, $source_post_id);
    $source = 'cpt';

    if (!empty($slots)) {
        if ($tag !== '') {
            $ttl = 60 * 10;
            is_tours_set_cached_slots_by_tag($tag, $slots, $ttl);
            is_tours_set_cached_source_by_tag($tag, $source, $ttl);
        }

        $payload = ['source' => $source, 'slots' => $slots];
        $etag = is_tours_build_etag($payload);
        $cached_at = $tag !== '' ? is_tours_get_cached_at_by_tag($tag) : 0;
        $max_age = 60;
        $maybe = is_tours_maybe_304($request, $etag, $cached_at, $max_age);
        if ($maybe) {
            $maybe->header('X-IS-Tours-Source', $source);
            if ($source === 'cpt') {
                $maybe->header('X-IS-Tours-Fallback', 'cpt');
            }
            return $maybe;
        }

        $res = new WP_REST_Response($payload, 200);
        $res->header('X-IS-Tours-Source', $source);
        if ($source === 'cpt') {
            $res->header('X-IS-Tours-Fallback', 'cpt');
        }
        if ($etag !== '') $res->header('ETag', $etag);
        $res->header('Cache-Control', 'public, max-age=' . $max_age);
        if ($cached_at > 0) {
            $res->header('Last-Modified', gmdate('D, d M Y H:i:s', $cached_at) . ' GMT');
        }
        return $res;
    }

    $res = new WP_REST_Response(['source' => $source, 'slots' => []], 200);
    $res->header('X-IS-Tours-Source', $source);
    $res->header('Cache-Control', 'no-store');
    return $res;
}

/**
 * Return cached slots for a given tag, or an empty array when not cached.
 */
function is_tours_get_cached_slots_by_tag($tag) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    if ($tag === '') {
        return [];
    }

    $cache_key = 'is_tours_slots_' . md5($tag);
    $cached = get_transient($cache_key);
    if ($cached === false || !is_array($cached)) {
        return [];
    }

    return $cached;
}

function is_tours_get_cached_source_by_tag($tag) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    if ($tag === '') {
        return '';
    }

    $cache_key = 'is_tours_slots_src_' . md5($tag);
    $src = get_transient($cache_key);
    return $src ? (string) $src : '';
}

/**
 * Return when the tag cache was last written (unix timestamp), or 0.
 */
function is_tours_get_cached_at_by_tag($tag) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    if ($tag === '') {
        return 0;
    }

    $cache_key = 'is_tours_slots_ts_' . md5($tag);
    $ts = get_transient($cache_key);
    return $ts ? (int) $ts : 0;
}

/**
 * Store normalized slots into the shared tag cache.
 *
 * @param string $tag
 * @param array $slots
 * @param int $ttl_seconds
 * @return void
 */
function is_tours_set_cached_slots_by_tag($tag, $slots, $ttl_seconds) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    if ($tag === '') return;

    if (!is_array($slots)) {
        $slots = [];
    }

    $ttl_seconds = (int) $ttl_seconds;
    if ($ttl_seconds <= 0) {
        $ttl_seconds = 60 * 10;
    }

    $cache_key = 'is_tours_slots_' . md5($tag);
    set_transient($cache_key, $slots, $ttl_seconds);

    $ts_key = 'is_tours_slots_ts_' . md5($tag);
    set_transient($ts_key, (int) current_time('timestamp'), $ttl_seconds);
}

function is_tours_set_cached_source_by_tag($tag, $source, $ttl_seconds) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    if ($tag === '') return;

    $source = sanitize_key((string) $source);
    if ($source === '') return;

    $ttl_seconds = (int) $ttl_seconds;
    if ($ttl_seconds <= 0) {
        $ttl_seconds = 60 * 10;
    }

    $cache_key = 'is_tours_slots_src_' . md5($tag);
    set_transient($cache_key, $source, $ttl_seconds);
}

function is_tours_build_etag($data) {
    try {
        $json = wp_json_encode($data);
        if (!is_string($json)) return '';
        return '"' . md5($json) . '"';
    } catch (Throwable $e) {
        return '';
    }
}

/**
 * Apply HTTP cache headers + conditional GET handling.
 *
 * @return WP_REST_Response|null Return a 304 response to short-circuit, or null to continue.
 */
function is_tours_maybe_304(WP_REST_Request $request, $etag, $last_modified_ts, $max_age) {
    $etag = (string) $etag;
    $last_modified_ts = (int) $last_modified_ts;
    $max_age = (int) $max_age;
    if ($max_age <= 0) {
        $max_age = 60;
    }

    if ($etag !== '') {
        $if_none_match = (string) $request->get_header('if-none-match');
        if ($if_none_match !== '' && trim($if_none_match) === $etag) {
            $res = new WP_REST_Response(null, 304);
            $res->header('ETag', $etag);
            $res->header('Cache-Control', 'public, max-age=' . $max_age);
            if ($last_modified_ts > 0) {
                $res->header('Last-Modified', gmdate('D, d M Y H:i:s', $last_modified_ts) . ' GMT');
            }
            return $res;
        }
    }

    if ($last_modified_ts > 0) {
        $if_modified_since = (string) $request->get_header('if-modified-since');
        if ($if_modified_since !== '') {
            $since = strtotime($if_modified_since);
            if ($since && $since >= $last_modified_ts) {
                $res = new WP_REST_Response(null, 304);
                if ($etag !== '') {
                    $res->header('ETag', $etag);
                }
                $res->header('Cache-Control', 'public, max-age=' . $max_age);
                $res->header('Last-Modified', gmdate('D, d M Y H:i:s', $last_modified_ts) . ' GMT');
                return $res;
            }
        }
    }

    return null;
}

/**
 * Return the next available slot from cache for a tag (or null).
 */
function is_tours_get_next_slot($tag) {
    $slots = is_tours_get_cached_slots_by_tag($tag);

    foreach ($slots as $slot) {
        if (!is_array($slot)) {
            continue;
        }

        if (!array_key_exists('available', $slot) || $slot['available'] === null || (int) $slot['available'] > 0) {
            return $slot;
        }
    }

    return null;
}

function is_tours_get_cpt_slots($tag, $source_post_id = 0) {
    $tag = strtoupper(sanitize_text_field((string) $tag));
    $source_post_id = (int) $source_post_id;

    if ($source_post_id > 0 && function_exists('iss_calendar_get_items_for_post')) {
        $items = iss_calendar_get_items_for_post($source_post_id, [
            'public_only' => true,
            'future_only' => true,
            'limit' => 250,
        ]);

        $slots = [];
        foreach ($items as $item) {
            if (!($item instanceof WP_Post)) {
                continue;
            }

            $item_id = (int) $item->ID;
            $external_id = trim((string) get_post_meta($item_id, 'external_id', true));
            $start = trim((string) get_post_meta($item_id, 'event_start', true));
            if ($external_id === '' || $start === '') {
                continue;
            }

            $end = trim((string) get_post_meta($item_id, 'event_end', true));
            $end = $end !== '' ? $end : null;
            $cap_raw = get_post_meta($item_id, 'capacity_total', true);
            $avail_raw = get_post_meta($item_id, 'capacity_available', true);

            $capacity = ($cap_raw === '' || $cap_raw === null) ? null : (int) $cap_raw;
            $available = ($avail_raw === '' || $avail_raw === null) ? null : (int) $avail_raw;
            $booking_url = trim((string) get_post_meta($item_id, 'booking_url', true));

            $slots[] = [
                'id' => (string) $external_id,
                'title' => is_saas_resolve_calendar_item_title($item_id),
                'start' => $start,
                'end' => $end,
                'capacity' => $capacity,
                'available' => $available,
                'booking_url' => $booking_url !== '' ? $booking_url : null,
                'content_url' => is_saas_resolve_calendar_item_content_url($item_id),
            ];
        }

        return $slots;
    }

    if ($tag !== '' && function_exists('iss_calendar_get_slots_fallback_for_tag')) {
        $fallback = iss_calendar_get_slots_fallback_for_tag($tag);
        return is_array($fallback) ? $fallback : [];
    }

    return [];
}

function is_tours_create_booking(WP_REST_Request $request) {
    $payload = json_decode($request->get_body(), true);
    if (!is_array($payload)) {
        return new WP_REST_Response(['ok' => false, 'error' => 'Invalid payload'], 400);
    }

    $name = sanitize_text_field($payload['name'] ?? '');
    $email = sanitize_email($payload['email'] ?? '');
    $tickets = isset($payload['tickets']) ? (int) $payload['tickets'] : 0;
    $slot_id = isset($payload['slot_id']) ? trim((string) $payload['slot_id']) : '';
    $payment = sanitize_text_field($payload['payment'] ?? '');

    $payload_tag = isset($payload['tag']) ? strtoupper(sanitize_text_field((string) $payload['tag'])) : '';
    $start = sanitize_text_field($payload['start'] ?? '');
    $title = sanitize_text_field($payload['title'] ?? '');
    $source_post_id = isset($payload['source_post_id']) ? (int) $payload['source_post_id'] : 0;
    $source_post_type = sanitize_key($payload['source_post_type'] ?? '');

    $tag = $payload_tag;
    if ($source_post_id > 0) {
        $resolved = strtoupper(sanitize_text_field((string) get_post_meta($source_post_id, 'calendar_tag', true)));
        if ($resolved === '' && function_exists('iss_calendar_resolve_tag_for_source_post_id')) {
            $resolved = iss_calendar_resolve_tag_for_source_post_id($source_post_id);
        }

        if ($tag === '' && $resolved !== '') {
            $tag = $resolved;
        } elseif ($tag !== '' && $resolved !== '' && $tag !== $resolved) {
            return new WP_REST_Response(['ok' => false, 'error' => 'Ungültige Zuordnung.'], 400);
        }
    }

    $errors = [];
    if ($name === '') { $errors[] = 'Name fehlt.'; }
    if (!is_email($email)) { $errors[] = 'Ungültige E-Mail.'; }
    if ($tickets < 1) { $errors[] = 'Bitte mindestens 1 Ticket.'; }
    if ($slot_id === '') { $errors[] = 'Slot fehlt.'; }
    if (!in_array($payment, ['onsite', 'mollie'], true)) { $errors[] = 'Ungültige Zahlungsart.'; }
    if ($tag === '' && $source_post_id <= 0) { $errors[] = 'Keine Zuordnung vorhanden.'; }

    if ($tag !== '' || $source_post_id > 0) {
        $slots = [];
        if ($tag !== '') {
            $slots = is_tours_get_cached_slots_by_tag($tag);
        }
        if (empty($slots)) {
            $slots = is_tours_get_cpt_slots($tag, $source_post_id);
            if ($tag !== '' && !empty($slots)) {
                is_tours_set_cached_slots_by_tag($tag, $slots, 60 * 10);
                is_tours_set_cached_source_by_tag($tag, 'cpt', 60 * 10);
            }
        }

        $found = null;
        foreach ($slots as $slot) {
            if (is_array($slot) && (string) ($slot['id'] ?? '') === (string) $slot_id) {
                $found = $slot;
                break;
            }
        }

        if ($found !== null) {
            if (array_key_exists('available', $found) && $found['available'] !== null && (int) $found['available'] <= 0) {
                $errors[] = 'Slot ist ausgebucht.';
            }
        } else {
            $errors[] = 'Ungültiger Slot.';
        }
    }

    if (!empty($errors)) {
        return new WP_REST_Response(['ok' => false, 'error' => implode(' ', $errors)], 400);
    }

    $entry = [
        'time' => current_time('mysql'),
        'name' => $name,
        'email' => $email,
        'tickets' => $tickets,
        'slot_id' => $slot_id,
        'payment' => $payment,
        'tag' => $tag,
        'start' => $start,
        'title' => $title,
        'source_post_id' => $source_post_id,
        'source_post_type' => $source_post_type,
        'ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field((string) $_SERVER['REMOTE_ADDR']) : '',
        'ua' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field((string) $_SERVER['HTTP_USER_AGENT']) : '',
    ];

    $requests = get_option('is_tours_booking_requests', []);
    if (!is_array($requests)) {
        $requests = [];
    }
    $requests[] = $entry;
    if (count($requests) > 200) {
        $requests = array_slice($requests, -200);
    }
    update_option('is_tours_booking_requests', $requests, false);

    /**
     * Hook for handling bookings (email, CRM, etc.).
     *
     * @param array $entry Sanitized booking entry.
     * @param WP_REST_Request $request Original REST request.
     */
    do_action('is_tours_booking_created', $entry, $request);

    return new WP_REST_Response(['ok' => true], 200);
}
